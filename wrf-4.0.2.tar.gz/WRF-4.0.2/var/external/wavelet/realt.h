!
! Author: Aime' Fournier
! E-mail: fournier@ucar.edu
!
! Use this to choose between `real*4' and `real*8' for arithmetic.
!

#ifndef REAL_HDR_ALREADY_INCLUDED
#define REAL_HDR_ALREADY_INCLUDED

#ifndef realt
# define realt REAL*8
#endif

#endif /* REAL_HDR_ALREADY_INCLUDED */
