void OpenWin();
void CloseWin();
int DefineGraph( char * label, float plus, float minus );
void InitGraph( int n, float Xmin, float Xmax, char *title );
void UpdateGraph( float * val );
